# frozen_string_literal: false
##
# For RubyGems backwards compatibility

module RDoc::RI::Formatter # :nodoc:
end
