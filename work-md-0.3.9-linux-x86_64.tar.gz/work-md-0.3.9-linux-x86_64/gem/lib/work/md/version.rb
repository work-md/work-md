# frozen_string_literal: true

module Work
  module Md
    VERSION = '0.3.9'
  end
end
