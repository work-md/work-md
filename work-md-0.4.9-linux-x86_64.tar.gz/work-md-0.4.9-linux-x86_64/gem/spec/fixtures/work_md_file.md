# 00/00/0000

### Tasks:

- [ ] Do something
- [x] Do something 2

---

### Meetings:

- [ ] Meeting
- [x] Meeting 2

---

### Interruptions:

- Some interruption

---

### Difficulties:

- Some difficulty

---

### Observations:

- Some observation

---

### Pomodoros / Cycles:

3
