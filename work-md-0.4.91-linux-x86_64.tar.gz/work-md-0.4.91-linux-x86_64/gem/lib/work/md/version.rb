# frozen_string_literal: true

module Work
  module Md
    VERSION = '0.4.91'
  end
end
