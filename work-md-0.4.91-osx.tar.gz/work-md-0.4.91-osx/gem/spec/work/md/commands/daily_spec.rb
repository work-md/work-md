require 'date'

RSpec.describe Work::Md::Commands::Daily do
  xdescribe '.execute' do
    # TODO
  end
end
