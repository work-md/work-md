# frozen_string_literal: true

module WorkMd
  VERSION = '0.3.4'
end
