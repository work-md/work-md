# frozen_string_literal: true

require_relative 'lib/work_md'

WorkMd::Cli.execute(ARGV)
