module Helpers
  def test_work_dir
    'spec/test_work_dir'
  end
end
