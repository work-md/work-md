# frozen_string_literal: true

module WorkMd
  VERSION = '0.3.3'
end
